﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mackiloha
{
    public struct Vector4
    {
        public float X;
        public float Y;
        public float Z;
        public float W;
    }
}
