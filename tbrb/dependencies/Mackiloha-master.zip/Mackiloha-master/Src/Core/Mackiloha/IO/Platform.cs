﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mackiloha.IO
{
    public enum Platform
    {
        PC,
        PS2,
        XBOX,
        GC,
        PS3,
        X360,
        Wii,
        PS4,
        XBONE,
        WiiU,
        Switch
    }
}
