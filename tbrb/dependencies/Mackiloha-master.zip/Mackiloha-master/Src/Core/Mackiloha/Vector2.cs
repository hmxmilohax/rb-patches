﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mackiloha
{
    public struct Vector2
    {
        public float X;
        public float Y;
    }
}
