﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mackiloha
{
    public struct Sphere
    {
        public float X;
        public float Y;
        public float Z;
        public float Radius;
    }
}
