﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mackiloha
{
    public struct Color4
    {
        public float R;
        public float G;
        public float B;
        public float A;
    }
}
