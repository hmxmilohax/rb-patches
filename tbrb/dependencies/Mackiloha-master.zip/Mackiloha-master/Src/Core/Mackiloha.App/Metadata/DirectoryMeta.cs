﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mackiloha.App.Metadata
{
    public struct DirectoryMeta
    {
        public string Name { get; set; }
        public string Type { get; set; }
    }
}
