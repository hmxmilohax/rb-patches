﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P9SongTool.Models
{
    public class LyricConfig
    {
        public string Name { get; set; }
        public LyricEvent[] Lyrics { get; set; }
    }
}
