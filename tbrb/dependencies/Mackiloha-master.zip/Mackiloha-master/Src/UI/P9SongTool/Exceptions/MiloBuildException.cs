﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P9SongTool.Exceptions
{
    public class MiloBuildException : Exception
    {
        public MiloBuildException(string message) : base(message)
        {

        }
    }
}
